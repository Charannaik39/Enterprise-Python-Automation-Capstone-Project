import io
import unittest

from pricewatch.config import AlertRule, Settings, parse_config, ConfigError
from pricewatch.engine import Pipeline
from pricewatch.scheduler import Scheduler
from pricewatch.storage import Store


class FakeClient:
    def __init__(self, seq):
        self.seq = list(seq)

    def get_prices(self, coins):
        return {"bitcoin": self.seq.pop(0)}


class Recorder:
    name = "rec"

    def __init__(self, fail=False):
        self.sent, self.fail = [], fail

    def send(self, subject, body):
        if self.fail:
            raise RuntimeError("boom")
        self.sent.append((subject, body))


def settings(**kw):
    rule = AlertRule(name="btc-hi", coin="bitcoin", type="threshold", value=100,
                     direction="above", cooldown_minutes=10)
    return Settings(alerts=(rule,), **kw)


class PipelineTest(unittest.TestCase):
    def test_fire_cooldown_then_refire(self):
        store, rec = Store(), Recorder()
        p = Pipeline(settings(), FakeClient([101, 102, 103]), store, [rec])
        self.assertEqual(p.run_cycle(now=1000).triggered, ["btc-hi"])
        r2 = p.run_cycle(now=1100)
        self.assertEqual((r2.triggered, r2.suppressed), ([], ["btc-hi"]))
        self.assertEqual(p.run_cycle(now=1000 + 601).triggered, ["btc-hi"])
        self.assertEqual(len(rec.sent), 2)
        self.assertEqual(len(store.recent_alerts()), 2)

    def test_failed_delivery_does_not_start_cooldown(self):
        store = Store()
        p = Pipeline(settings(), FakeClient([101, 101]), store, [Recorder(fail=True)])
        self.assertEqual(p.run_cycle(now=0).triggered, [])
        p.notifiers = [Recorder()]
        self.assertEqual(p.run_cycle(now=5).triggered, ["btc-hi"])

    def test_one_bad_notifier_does_not_block_others(self):
        good = Recorder()
        p = Pipeline(settings(), FakeClient([150]), Store(), [Recorder(fail=True), good])
        self.assertEqual(p.run_cycle(now=0).triggered, ["btc-hi"])
        self.assertEqual(len(good.sent), 1)

    def test_prune_and_export(self):
        store = Store()
        store.add_prices({"bitcoin": 1.0}, "usd", ts=0)
        store.add_prices({"bitcoin": 2.0}, "usd", ts=1_000_000)
        self.assertEqual(store.prune(500), 1)
        buf = io.StringIO()
        self.assertEqual(store.export_csv(buf), 1)
        self.assertIn("bitcoin,usd,2.0", buf.getvalue())


class SchedulerTest(unittest.TestCase):
    def test_runs_max_runs_and_survives_failures(self):
        calls = []

        def job():
            calls.append(1)
            if len(calls) == 2:
                raise RuntimeError("transient")

        s = Scheduler(0.01, job)
        self.assertEqual(s.run(max_runs=4), 4)
        self.assertEqual((len(calls), s.failures), (4, 1))

    def test_stop(self):
        s = Scheduler(0.01, lambda: s.stop())
        self.assertEqual(s.run(), 1)


class ConfigTest(unittest.TestCase):
    def test_valid(self):
        s = parse_config({"alerts": [{"coin": "Bitcoin", "type": "threshold", "value": 5}]})
        self.assertEqual(s.coins, ["bitcoin"])

    def test_invalid(self):
        for bad in (
            {},
            {"alerts": [{"coin": "b", "type": "nope", "value": 1}]},
            {"alerts": [{"coin": "b", "type": "threshold", "value": -1}]},
            {"alerts": [{"coin": "b", "type": "threshold", "value": 1, "direction": "up"}]},
            {"general": {"interval_seconds": 1},
             "alerts": [{"coin": "b", "type": "threshold", "value": 1}]},
        ):
            with self.assertRaises(ConfigError):
                parse_config(bad)


if __name__ == "__main__":
    unittest.main()
