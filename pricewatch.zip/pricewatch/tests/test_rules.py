import unittest

from pricewatch.config import AlertRule
from pricewatch.rules import evaluate, pct_change, sma
from pricewatch.storage import Sample


def rule(**kw):
    base = dict(name="r", coin="bitcoin", type="threshold", value=100.0)
    base.update(kw)
    return AlertRule(**base)


class RulesTest(unittest.TestCase):
    def test_pct_change(self):
        self.assertAlmostEqual(pct_change(100, 110), 10.0)
        with self.assertRaises(ZeroDivisionError):
            pct_change(0, 1)

    def test_threshold_above_and_below(self):
        self.assertIsNotNone(evaluate(rule(direction="above"), 100, [], 0))
        self.assertIsNone(evaluate(rule(direction="above"), 99.9, [], 0))
        self.assertIsNotNone(evaluate(rule(direction="below"), 90, [], 0))
        self.assertIsNone(evaluate(rule(direction="below"), 100.1, [], 0))

    def test_pct_change_fires_on_move(self):
        r = rule(type="pct_change", value=5, window_minutes=60, direction="any")
        hist = [Sample(0, 100.0), Sample(1800, 103.0), Sample(3600, 106.0)]
        self.assertIn("+6.00%", evaluate(r, 106.0, hist, 3600))

    def test_pct_change_direction_filter(self):
        r = rule(type="pct_change", value=5, window_minutes=60, direction="down")
        hist = [Sample(0, 100.0), Sample(3600, 110.0)]
        self.assertIsNone(evaluate(r, 110.0, hist, 3600))

    def test_pct_change_needs_enough_coverage(self):
        r = rule(type="pct_change", value=1, window_minutes=60)
        hist = [Sample(3500, 100.0), Sample(3600, 120.0)]  # only 100s of data for a 60-min window
        self.assertIsNone(evaluate(r, 120.0, hist, 3600))

    def test_sma_needs_samples_then_fires(self):
        r = rule(type="sma_deviation", value=3, samples=4)
        short = [Sample(i, 100.0) for i in range(3)]
        self.assertIsNone(evaluate(r, 110.0, short, 3))
        hist = [Sample(i, 100.0) for i in range(3)] + [Sample(3, 120.0)]
        self.assertEqual(sma(hist, 4), 105.0)
        self.assertIn("SMA", evaluate(r, 120.0, hist, 3))


if __name__ == "__main__":
    unittest.main()
