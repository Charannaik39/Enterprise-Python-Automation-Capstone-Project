import json
import unittest
import urllib.error
from email.message import Message

from pricewatch.api import CoinGeckoClient, PriceAPIError


def http_error(code, retry_after=None):
    hdrs = Message()
    if retry_after:
        hdrs["Retry-After"] = retry_after
    return urllib.error.HTTPError("http://x", code, "err", hdrs, None)


class ApiTest(unittest.TestCase):
    def make(self, responses, **kw):
        calls, sleeps = [], []

        def fetch(url, headers, timeout):
            calls.append(url)
            item = responses.pop(0)
            if isinstance(item, Exception):
                raise item
            return json.dumps(item).encode()

        return CoinGeckoClient(fetch=fetch, sleep=sleeps.append, **kw), calls, sleeps

    def test_success_and_missing_coin(self):
        c, calls, _ = self.make([{"bitcoin": {"usd": 123.5}}])
        self.assertEqual(c.get_prices(["bitcoin", "nope"]), {"bitcoin": 123.5})
        self.assertIn("ids=bitcoin%2Cnope", calls[0])

    def test_retries_then_succeeds_with_backoff(self):
        c, calls, sleeps = self.make(
            [http_error(503), urllib.error.URLError("down"), {"bitcoin": {"usd": 1}}],
            max_retries=3, backoff=1.0)
        self.assertEqual(c.get_prices(["bitcoin"]), {"bitcoin": 1.0})
        self.assertEqual(sleeps, [1.0, 2.0])

    def test_429_honours_retry_after(self):
        c, _, sleeps = self.make([http_error(429, "7"), {"bitcoin": {"usd": 1}}])
        c.get_prices(["bitcoin"])
        self.assertEqual(sleeps, [7.0])

    def test_client_error_not_retried(self):
        c, calls, _ = self.make([http_error(404)])
        with self.assertRaises(PriceAPIError):
            c.get_prices(["bitcoin"])
        self.assertEqual(len(calls), 1)

    def test_gives_up_after_max_retries(self):
        c, calls, _ = self.make([http_error(500)] * 3, max_retries=3)
        with self.assertRaises(PriceAPIError):
            c.get_prices(["bitcoin"])
        self.assertEqual(len(calls), 3)


if __name__ == "__main__":
    unittest.main()
