import contextlib
import io
import os
import tempfile
import unittest

from pricewatch.cli import main


class CliTest(unittest.TestCase):
    def run_cli(self, *argv):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = main(list(argv))
        return code, out.getvalue(), err.getvalue()

    def test_init_validate_and_history_empty(self):
        with tempfile.TemporaryDirectory() as d:
            cfg = os.path.join(d, "pw.toml")
            self.assertEqual(self.run_cli("init", cfg)[0], 0)
            self.assertEqual(self.run_cli("init", cfg)[0], 1)  # refuses to overwrite
            code, out, _ = self.run_cli("validate", "-c", cfg)
            self.assertEqual(code, 0)
            self.assertIn("3 alert(s)", out)
            os.environ["PRICEWATCH_DB"] = os.path.join(d, "t.db")
            try:
                code, out, _ = self.run_cli("history", "bitcoin", "-c", cfg)
                self.assertEqual(code, 0)
                self.assertIn("no samples", out)
                self.assertIn("no alerts", self.run_cli("alerts", "-c", cfg)[1])
            finally:
                del os.environ["PRICEWATCH_DB"]

    def test_missing_config_exit_code(self):
        code, _, err = self.run_cli("validate", "-c", "/nonexistent.toml")
        self.assertEqual(code, 2)
        self.assertIn("not found", err)


if __name__ == "__main__":
    unittest.main()
