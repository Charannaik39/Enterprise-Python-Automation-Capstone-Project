# pricewatch — Automated Crypto Price Alert Bot

[![CI](https://img.shields.io/badge/CI-GitHub_Actions-blue)](.github/workflows/ci.yml)
![python](https://img.shields.io/badge/python-3.11%2B-blue)
![deps](https://img.shields.io/badge/runtime_dependencies-0-brightgreen)

`pricewatch` polls a public market-data API on a fixed schedule, stores every sample in SQLite,
evaluates configurable alert rules (price thresholds, percentage moves, moving-average deviation)
and delivers notifications to the console, Slack/Discord webhooks, Telegram or e-mail.

It is a complete, production-style Python application: **API integration → data processing →
persistence → scheduling → notification**, packaged with a CLI, tests, CI, Docker and systemd files.

## Contents

1. [Features](#features)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Quick start](#quick-start)
5. [CLI reference](#cli-reference)
6. [Configuration](#configuration)
7. [Alert rules explained](#alert-rules-explained)
8. [Deployment](#deployment)
9. [Testing](#testing)
10. [Design decisions](#design-decisions)
11. [Project layout](#project-layout)
12. [Limitations and roadmap](#limitations-and-roadmap)

## Features

| Area | What it does |
|------|--------------|
| Backend API | CoinGecko `/simple/price` client with timeouts, exponential backoff, `Retry-After` support, and no retry on 4xx errors |
| Data processing | Percent change over a time window, simple moving average (SMA), direction filters, coverage checks |
| Persistence | SQLite (WAL mode) for price history and alert log; CSV export; automatic retention pruning |
| Scheduling | Drift-free fixed-rate scheduler, fault isolation (one failed run never kills the bot), graceful `SIGINT`/`SIGTERM` shutdown |
| Alerting | Per-rule cooldowns, multiple notifier channels, failure isolation between channels |
| Packaging | `pyproject.toml`, `pricewatch` console script, `python -m pricewatch`, zero runtime dependencies |
| Quality | 21 unit tests, injected dependencies (HTTP, clock, sleep) so everything is testable offline |

## Architecture

### Component view

```mermaid
flowchart LR
    CLI["cli.py<br/>argparse commands"] --> CFG["config.py<br/>TOML + validation"]
    CLI --> SCH["scheduler.py<br/>fixed-rate loop"]
    SCH -->|every N seconds| PIPE["engine.py<br/>Pipeline.tick()"]
    PIPE --> API["api.py<br/>CoinGeckoClient"]
    API -->|HTTPS + retries| EXT[("CoinGecko API")]
    PIPE --> DB[("SQLite<br/>prices, alert_log")]
    PIPE --> RULES["rules.py<br/>pure evaluation"]
    RULES --> DB
    PIPE --> NOTI["notifiers.py"]
    NOTI --> C["Console"]
    NOTI --> W["Webhook<br/>Slack / Discord"]
    NOTI --> T["Telegram"]
    NOTI --> M["SMTP e-mail"]
```

### One monitoring cycle

```mermaid
sequenceDiagram
    participant S as Scheduler
    participant P as Pipeline
    participant A as API client
    participant D as SQLite
    participant R as Rules
    participant N as Notifiers
    S->>P: tick()
    P->>A: get_prices(coins)
    A-->>P: {bitcoin: 98123.4, ...}
    P->>D: add_prices()
    loop each alert rule
        P->>D: history(coin, window)
        P->>R: evaluate(rule, price, history)
        R-->>P: message or None
        alt fired and not in cooldown
            P->>N: send(subject, body)
            N-->>P: delivered to >= 1 channel
            P->>D: log_alert() (starts cooldown)
        end
    end
    P->>D: prune() (once per 24h)
```

### Layering

* **`rules.py` is pure** (no I/O): data in, message out. This is where the business logic lives.
* **`engine.py` orchestrates** and is the only place where API, DB, rules and notifiers meet.
* **Everything external is injectable** (`fetch`, `sleep`, `clock`, notifier list), which is why the tests
  need no network or real waiting.

## Installation

Requires Python 3.11+ (uses `tomllib`). No third-party runtime dependencies.

```bash
git clone <your-repo-url> pricewatch && cd pricewatch
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -e ".[dev]"      # development
# or: pip install .          # plain install
pricewatch --version
```

## Quick start

```bash
pricewatch init                 # writes pricewatch.toml from the example
pricewatch validate             # checks config + notifier secrets
pricewatch price bitcoin ethereum          # ad-hoc lookup, no config needed
pricewatch run --once --dry-run # single cycle, alerts printed to console
pricewatch -v run               # start the scheduled monitor (Ctrl+C to stop)
```

Example output:

```
$ pricewatch price bitcoin ethereum
bitcoin                 98,123.40 USD
ethereum                 3,412.77 USD

$ pricewatch -v run
2026-10-07 10:00:01 INFO    pricewatch.cli: monitoring bitcoin, ethereum, solana every 60s (Ctrl+C to stop)
2026-10-07 10:00:02 INFO    pricewatch.engine: fetched bitcoin=98,123.40, ethereum=3,412.77, solana=161.20
🚨 [pricewatch] ETH 5% move in 1h
   ethereum moved +5.31% in 61 min (3,240.10 -> 3,412.77)

$ pricewatch history ethereum --hours 6 --tail 3
ethereum: 361 samples over 6.0h
  first 3,198.50 | last 3,412.77 | min 3,190.02 | max 3,420.11 | avg 3,301.45 | change +6.70%
  2026-10-07 10:00:02       3,412.77
```

## CLI reference

| Command | Purpose | Key options |
|---------|---------|-------------|
| `pricewatch init [path]` | Write an example config | `--force` |
| `pricewatch validate` | Validate config and referenced secrets | `-c FILE` |
| `pricewatch run` | Start the scheduled monitor | `--once`, `--dry-run`, `-c FILE` |
| `pricewatch price COIN...` | Fetch current prices | `--vs usd` |
| `pricewatch history COIN` | Summary stats + recent samples | `--hours 24`, `--tail 10` |
| `pricewatch alerts` | Recently fired alerts | `--limit 20` |
| `pricewatch export` | Dump history to CSV | `-o FILE` (`-` = stdout), `--coin` |

Global flags: `-v` (INFO), `-vv` (DEBUG), `--version`.
Exit codes: `0` success, `1` refused action, `2` config/API error, `130` interrupted.

## Configuration

Config is a TOML file (see [`src/pricewatch/config.example.toml`](src/pricewatch/config.example.toml)).

```toml
[general]
interval_seconds = 60      # >= 5
vs_currency = "usd"
retention_days = 30

[[alerts]]
name = "BTC above 100k"
coin = "bitcoin"           # CoinGecko id
type = "threshold"
direction = "above"
value = 100000
cooldown_minutes = 120

[[notifiers]]
type = "telegram"
token_env = "PRICEWATCH_TG_TOKEN"   # secret read from the environment
chat_id = "123456789"
```

**Secrets never live in the config file**: use the `*_env` options (`url_env`, `token_env`,
`username_env`, `password_env`). `pricewatch validate` fails fast if a referenced variable is unset.
`PRICEWATCH_DB` overrides `general.db_path` (used by the Docker image).

## Alert rules explained

| `type` | Fires when | Options |
|--------|-----------|---------|
| `threshold` | price `>=` (above) or `<=` (below) `value` | `direction = above \| below` |
| `pct_change` | `abs(% change)` over `window_minutes` is `>= value` | `direction = up \| down \| any`, `window_minutes` |
| `sma_deviation` | price is `>= value`% away from the mean of the last `samples` points | `direction`, `samples` |

Guard rails that avoid noisy or misleading alerts:

* **Cooldown**: after a rule fires, it stays quiet for `cooldown_minutes`.
* **Delivery-aware cooldown**: if *every* notifier fails, the cooldown does **not** start, so the alert is retried next cycle.
* **Coverage check**: `pct_change` needs history spanning at least half of `window_minutes`, so a freshly started bot does not report a "5% move" measured over 30 seconds.
* **Warm-up**: `sma_deviation` stays silent until `samples` points exist.

## Deployment

**Docker**

```bash
docker build -t pricewatch .
mkdir data && docker run --rm -v "$PWD/data:/data" pricewatch init /data/pricewatch.toml
docker run -d --name pricewatch --restart unless-stopped -v "$PWD/data:/data" \
  -e PRICEWATCH_TG_TOKEN=... pricewatch
```

**systemd** (Linux): see [`deploy/pricewatch.service`](deploy/pricewatch.service). Put secrets in
`/etc/pricewatch/env`, then `systemctl enable --now pricewatch`.

**cron alternative**: `* * * * * pricewatch run --once -c /etc/pricewatch/pricewatch.toml`
(works because all state, including cooldowns, lives in SQLite).

## Testing

```bash
pip install -e ".[dev]"
pytest --cov=pricewatch          # or: python -m unittest discover -s tests
ruff check .
```

| Test module | Covers |
|-------------|--------|
| `test_rules.py` | threshold, pct_change (direction, coverage), SMA warm-up/firing |
| `test_api.py` | retries, exponential backoff, `Retry-After`, no retry on 404, give-up |
| `test_pipeline.py` | cooldown/re-fire, failed delivery, channel isolation, pruning, CSV, scheduler, config validation |
| `test_cli.py` | `init` / `validate` / `history` / `alerts`, exit codes |

## Design decisions

* **Standard library only.** `urllib`, `sqlite3`, `tomllib`, `argparse`: nothing to audit or pin, simple to deploy.
  Swapping to `requests`/`click` is a small, local change if desired.
* **Fixed-rate scheduler instead of `sleep(interval)`**, so job duration does not cause drift; missed ticks are skipped, not stacked.
* **SQLite for state**, so restarts keep history and cooldowns, and the cron mode works.
* **Dependency injection over mocking frameworks.** HTTP fetcher, clock and sleep are constructor arguments.
* **Fail soft per component.** A failed API call raises `PriceAPIError` for that cycle only; a broken notifier never blocks others.

## Project layout

```
pricewatch/
├── pyproject.toml            # packaging, entry point, tool config
├── README.md
├── Dockerfile
├── deploy/pricewatch.service
├── .github/workflows/ci.yml
├── src/pricewatch/
│   ├── cli.py                # argparse commands
│   ├── config.py             # TOML loading + validation
│   ├── config.example.toml
│   ├── api.py                # CoinGecko client
│   ├── storage.py            # SQLite store
│   ├── rules.py              # pure alert logic
│   ├── engine.py             # pipeline orchestration
│   ├── notifiers.py          # console / webhook / telegram / smtp
│   └── scheduler.py          # fixed-rate loop
└── tests/
```

## Limitations and roadmap

* The free CoinGecko tier is rate limited; keep `interval_seconds` at 30 s or more for several coins.
* Crypto only; a stock provider would implement the same `get_prices(ids) -> {id: price}` interface.
* Ideas: async fetching, Prometheus metrics endpoint, per-rule notifier routing, hysteresis for threshold alerts.

> Not financial advice. Prices come from a third-party API and may be delayed or inaccurate.

## License

MIT
