import sys

from pricewatch.cli import main

sys.exit(main())
