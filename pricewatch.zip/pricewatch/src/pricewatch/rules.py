"""Pure data-processing / rule evaluation. No I/O, fully unit-testable."""

from __future__ import annotations

from statistics import fmean

from pricewatch.config import AlertRule
from pricewatch.storage import Sample


def pct_change(old: float, new: float) -> float:
    if old == 0:
        raise ZeroDivisionError("baseline price is zero")
    return (new - old) / old * 100.0


def sma(samples: list[Sample], n: int) -> float | None:
    """Simple moving average of the last n samples, or None if not enough data."""
    if len(samples) < n:
        return None
    return fmean(s.price for s in samples[-n:])


def history_window_seconds(rule: AlertRule) -> float:
    """How far back the engine must load history for this rule (pct_change only)."""
    return rule.window_minutes * 60 * 2.0


def _direction_ok(direction: str, change: float) -> bool:
    return direction == "any" or (direction == "up" and change > 0) or (
        direction == "down" and change < 0)


def evaluate(rule: AlertRule, price: float, history: list[Sample], now: float) -> str | None:
    """Return an alert message if `rule` fires for `price`, else None.

    `history` is ascending and already includes the current sample.
    """
    if rule.type == "threshold":
        hit = price >= rule.value if rule.direction == "above" else price <= rule.value
        if hit:
            return (f"{rule.coin} is {price:,.2f}, {rule.direction} "
                    f"threshold {rule.value:,.2f}")
        return None

    if rule.type == "pct_change":
        window = rule.window_minutes * 60
        cutoff = now - window
        older = [s for s in history if s.ts <= cutoff]
        baseline = older[-1] if older else (history[0] if history else None)
        # Require the baseline to cover at least half the window, else the % is misleading.
        if baseline is None or now - baseline.ts < window * 0.5 or baseline.ts >= now:
            return None
        change = pct_change(baseline.price, price)
        if abs(change) >= rule.value and _direction_ok(rule.direction, change):
            minutes = (now - baseline.ts) / 60
            return (f"{rule.coin} moved {change:+.2f}% in {minutes:.0f} min "
                    f"({baseline.price:,.2f} -> {price:,.2f})")
        return None

    if rule.type == "sma_deviation":
        avg = sma(history, rule.samples)
        if avg is None or avg == 0:
            return None
        dev = pct_change(avg, price)
        if abs(dev) >= rule.value and _direction_ok(rule.direction, dev):
            return (f"{rule.coin} is {dev:+.2f}% from its {rule.samples}-sample SMA "
                    f"({avg:,.2f}); price {price:,.2f}")
        return None

    raise ValueError(f"unknown rule type: {rule.type}")
