"""Pipeline: fetch -> persist -> evaluate rules -> notify (with cooldowns)."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field

from pricewatch.api import CoinGeckoClient
from pricewatch.config import Settings
from pricewatch.notifiers import Notifier
from pricewatch.rules import evaluate, history_window_seconds
from pricewatch.storage import Store

log = logging.getLogger(__name__)
PRUNE_EVERY_SECONDS = 24 * 3600


@dataclass
class CycleResult:
    prices: dict[str, float] = field(default_factory=dict)
    triggered: list[str] = field(default_factory=list)   # alert names that fired + delivered
    suppressed: list[str] = field(default_factory=list)  # fired but inside cooldown


class Pipeline:
    def __init__(self, settings: Settings, client: CoinGeckoClient, store: Store,
                 notifiers: list[Notifier]) -> None:
        self.settings, self.client, self.store, self.notifiers = settings, client, store, notifiers
        self._last_prune = 0.0

    def run_cycle(self, now: float | None = None) -> CycleResult:
        now = time.time() if now is None else now
        s = self.settings
        result = CycleResult()

        result.prices = self.client.get_prices(s.coins)
        self.store.add_prices(result.prices, s.vs_currency, ts=now)
        log.info("fetched %s", ", ".join(f"{c}={p:,.2f}" for c, p in result.prices.items()))

        for rule in s.alerts:
            price = result.prices.get(rule.coin)
            if price is None:
                continue
            if rule.type == "sma_deviation":
                history = self.store.history(rule.coin, s.vs_currency, limit=rule.samples)
            else:
                history = self.store.history(
                    rule.coin, s.vs_currency, since=now - history_window_seconds(rule))
            message = evaluate(rule, price, history, now)
            if message is None:
                continue

            last = self.store.last_alert_ts(rule.name)
            if last is not None and now - last < rule.cooldown_minutes * 60:
                result.suppressed.append(rule.name)
                log.debug("alert '%s' suppressed by cooldown", rule.name)
                continue

            if self._dispatch(f"[pricewatch] {rule.name}", message):
                self.store.log_alert(rule.name, rule.coin, price, message, ts=now)
                result.triggered.append(rule.name)
        return result

    def _dispatch(self, subject: str, body: str) -> bool:
        """Send via all notifiers; True if at least one succeeded (or none configured)."""
        if not self.notifiers:
            return True
        delivered = 0
        for n in self.notifiers:
            try:
                n.send(subject, body)
                delivered += 1
            except Exception:  # one broken channel must not stop the others
                log.exception("notifier '%s' failed", n.name)
        return delivered > 0

    def maybe_prune(self, now: float | None = None) -> int:
        now = time.time() if now is None else now
        if now - self._last_prune < PRUNE_EVERY_SECONDS:
            return 0
        self._last_prune = now
        removed = self.store.prune(now - self.settings.retention_days * 86400)
        if removed:
            log.info("pruned %d old samples", removed)
        return removed

    def tick(self) -> CycleResult:
        """One scheduler job: a cycle plus periodic housekeeping."""
        result = self.run_cycle()
        self.maybe_prune()
        return result
