"""Configuration loading and validation (TOML)."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

THRESHOLD_DIRECTIONS = {"above", "below"}
MOVE_DIRECTIONS = {"up", "down", "any"}
RULE_TYPES = {"threshold", "pct_change", "sma_deviation"}
NOTIFIER_TYPES = {"console", "webhook", "telegram", "smtp"}


class ConfigError(ValueError):
    """Raised when the configuration file is missing or invalid."""


@dataclass(frozen=True)
class AlertRule:
    name: str
    coin: str
    type: str
    value: float
    direction: str = "any"
    window_minutes: int = 60
    samples: int = 20
    cooldown_minutes: int = 60


@dataclass(frozen=True)
class NotifierConfig:
    type: str
    options: dict[str, Any]


@dataclass(frozen=True)
class Settings:
    db_path: str = "pricewatch.db"
    interval_seconds: int = 60
    vs_currency: str = "usd"
    retention_days: int = 30
    request_timeout: float = 10.0
    max_retries: int = 3
    alerts: tuple[AlertRule, ...] = ()
    notifiers: tuple[NotifierConfig, ...] = ()

    @property
    def coins(self) -> list[str]:
        return sorted({a.coin for a in self.alerts})


def _require(table: dict, key: str, ctx: str) -> Any:
    if key not in table:
        raise ConfigError(f"{ctx}: missing required key '{key}'")
    return table[key]


def _parse_rule(raw: dict, idx: int) -> AlertRule:
    ctx = f"alerts[{idx}]"
    rtype = _require(raw, "type", ctx)
    if rtype not in RULE_TYPES:
        raise ConfigError(f"{ctx}: type must be one of {sorted(RULE_TYPES)}, got '{rtype}'")
    default_dir = "above" if rtype == "threshold" else "any"
    direction = raw.get("direction", default_dir)
    allowed = THRESHOLD_DIRECTIONS if rtype == "threshold" else MOVE_DIRECTIONS
    if direction not in allowed:
        raise ConfigError(f"{ctx}: direction for '{rtype}' must be one of {sorted(allowed)}")
    try:
        value = float(_require(raw, "value", ctx))
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"{ctx}: value must be a number") from exc
    if value <= 0:
        raise ConfigError(f"{ctx}: value must be > 0")
    rule = AlertRule(
        name=str(raw.get("name") or f"{raw.get('coin')}-{rtype}-{idx}"),
        coin=str(_require(raw, "coin", ctx)).lower(),
        type=rtype,
        value=value,
        direction=direction,
        window_minutes=int(raw.get("window_minutes", 60)),
        samples=int(raw.get("samples", 20)),
        cooldown_minutes=int(raw.get("cooldown_minutes", 60)),
    )
    if rule.window_minutes < 1 or rule.samples < 2 or rule.cooldown_minutes < 0:
        raise ConfigError(f"{ctx}: window_minutes>=1, samples>=2, cooldown_minutes>=0 required")
    return rule


def parse_config(data: dict) -> Settings:
    general = data.get("general", {})
    interval = int(general.get("interval_seconds", 60))
    if interval < 5:
        raise ConfigError("general.interval_seconds must be >= 5 (public API rate limits)")
    alerts = tuple(_parse_rule(a, i) for i, a in enumerate(data.get("alerts", [])))
    if not alerts:
        raise ConfigError("at least one [[alerts]] entry is required")
    names = [a.name for a in alerts]
    if len(set(names)) != len(names):
        raise ConfigError("alert names must be unique")
    notifiers = []
    for i, raw in enumerate(data.get("notifiers", [{"type": "console"}])):
        ntype = raw.get("type")
        if ntype not in NOTIFIER_TYPES:
            raise ConfigError(f"notifiers[{i}]: type must be one of {sorted(NOTIFIER_TYPES)}")
        notifiers.append(NotifierConfig(ntype, {k: v for k, v in raw.items() if k != "type"}))
    return Settings(
        db_path=os.environ.get("PRICEWATCH_DB", general.get("db_path", "pricewatch.db")),
        interval_seconds=interval,
        vs_currency=str(general.get("vs_currency", "usd")).lower(),
        retention_days=int(general.get("retention_days", 30)),
        request_timeout=float(general.get("request_timeout", 10.0)),
        max_retries=int(general.get("max_retries", 3)),
        alerts=alerts,
        notifiers=tuple(notifiers),
    )


def load_config(path: str | Path) -> Settings:
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"config file not found: {p} (run `pricewatch init`)")
    try:
        data = tomllib.loads(p.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"invalid TOML in {p}: {exc}") from exc
    return parse_config(data)
