"""SQLite persistence for price samples and alert history."""

from __future__ import annotations

import csv
import sqlite3
import time
from collections.abc import Iterable
from dataclasses import dataclass
from typing import TextIO

SCHEMA = """
CREATE TABLE IF NOT EXISTS prices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    coin TEXT NOT NULL,
    vs TEXT NOT NULL,
    price REAL NOT NULL,
    ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_prices_coin_ts ON prices(coin, vs, ts);
CREATE TABLE IF NOT EXISTS alert_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    coin TEXT NOT NULL,
    price REAL NOT NULL,
    message TEXT NOT NULL,
    ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alert_name_ts ON alert_log(name, ts);
"""


@dataclass(frozen=True)
class Sample:
    ts: float
    price: float


class Store:
    def __init__(self, path: str = ":memory:") -> None:
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        if path != ":memory:":
            self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(SCHEMA)

    def __enter__(self) -> Store:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self.conn.close()

    # ---- prices -----------------------------------------------------------
    def add_prices(self, prices: dict[str, float], vs: str, ts: float | None = None) -> None:
        ts = time.time() if ts is None else ts
        with self.conn:
            self.conn.executemany(
                "INSERT INTO prices(coin, vs, price, ts) VALUES (?,?,?,?)",
                [(c, vs, p, ts) for c, p in prices.items()],
            )

    def history(self, coin: str, vs: str, since: float | None = None,
                limit: int | None = None) -> list[Sample]:
        """Samples in ascending time order. With `limit`, returns the most recent N."""
        sql, args = "SELECT ts, price FROM prices WHERE coin=? AND vs=?", [coin, vs]
        if since is not None:
            sql += " AND ts>=?"
            args.append(since)
        if limit is not None:
            rows = self.conn.execute(sql + " ORDER BY ts DESC LIMIT ?", [*args, limit]).fetchall()
            rows.reverse()
        else:
            rows = self.conn.execute(sql + " ORDER BY ts ASC", args).fetchall()
        return [Sample(r["ts"], r["price"]) for r in rows]

    def prune(self, older_than: float) -> int:
        with self.conn:
            cur = self.conn.execute("DELETE FROM prices WHERE ts<?", (older_than,))
        return cur.rowcount

    # ---- alerts -----------------------------------------------------------
    def last_alert_ts(self, name: str) -> float | None:
        row = self.conn.execute("SELECT MAX(ts) AS t FROM alert_log WHERE name=?", (name,)).fetchone()
        return row["t"]

    def log_alert(self, name: str, coin: str, price: float, message: str,
                  ts: float | None = None) -> None:
        with self.conn:
            self.conn.execute(
                "INSERT INTO alert_log(name, coin, price, message, ts) VALUES (?,?,?,?,?)",
                (name, coin, price, message, time.time() if ts is None else ts),
            )

    def recent_alerts(self, limit: int = 20) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM alert_log ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()

    # ---- export -----------------------------------------------------------
    def export_csv(self, fp: TextIO, coin: str | None = None) -> int:
        sql, args = "SELECT coin, vs, price, ts FROM prices", []
        if coin:
            sql += " WHERE coin=?"
            args.append(coin)
        rows: Iterable[sqlite3.Row] = self.conn.execute(sql + " ORDER BY ts ASC", args)
        writer = csv.writer(fp)
        writer.writerow(["coin", "vs_currency", "price", "timestamp_utc"])
        n = 0
        for r in rows:
            iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(r["ts"]))
            writer.writerow([r["coin"], r["vs"], r["price"], iso])
            n += 1
        return n
