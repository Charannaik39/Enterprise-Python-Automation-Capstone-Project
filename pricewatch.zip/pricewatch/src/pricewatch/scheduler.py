"""Fixed-rate scheduler with graceful shutdown and fault isolation."""

from __future__ import annotations

import logging
import signal
import threading
import time
from collections.abc import Callable

log = logging.getLogger(__name__)


class Scheduler:
    """Runs `job` every `interval` seconds until stopped.

    Fixed-rate (no drift): the next deadline is computed from the previous deadline,
    not from when the job finished. A failing job is logged and retried next tick.
    """

    def __init__(self, interval: float, job: Callable[[], object],
                 clock: Callable[[], float] = time.monotonic,
                 stop_event: threading.Event | None = None) -> None:
        self.interval, self.job, self.clock = interval, job, clock
        self._stop = stop_event or threading.Event()
        self.failures = 0

    def stop(self) -> None:
        self._stop.set()

    def install_signal_handlers(self) -> None:
        def handler(signum, _frame):
            log.info("received %s, shutting down", signal.Signals(signum).name)
            self.stop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            signal.signal(sig, handler)

    def run(self, max_runs: int | None = None) -> int:
        runs = 0
        next_run = self.clock()
        while not self._stop.is_set():
            try:
                self.job()
            except Exception:
                self.failures += 1
                log.exception("job failed (consecutive/total failures: %d)", self.failures)
            runs += 1
            if max_runs is not None and runs >= max_runs:
                break
            next_run += self.interval
            now = self.clock()
            if next_run < now:  # fell behind (long job / suspend): skip missed ticks
                next_run = now
            self._stop.wait(next_run - now)
        return runs
