"""Notification channels. Each notifier implements send(subject, body)."""

from __future__ import annotations

import json
import logging
import os
import smtplib
import urllib.request
from email.message import EmailMessage
from typing import Protocol

from pricewatch.config import ConfigError, NotifierConfig

log = logging.getLogger(__name__)


class Notifier(Protocol):
    name: str

    def send(self, subject: str, body: str) -> None: ...


def _secret(options: dict, key: str, required: bool = True) -> str | None:
    """Resolve `<key>_env` (preferred) or inline `<key>` from the environment/config."""
    env_name = options.get(f"{key}_env")
    if env_name:
        value = os.environ.get(env_name)
        if value:
            return value
        if required:
            raise ConfigError(f"environment variable {env_name} is not set")
        return None
    value = options.get(key)
    if value is None and required:
        raise ConfigError(f"notifier option '{key}' (or '{key}_env') is required")
    return value


def _post_json(url: str, payload: dict, timeout: float = 10.0) -> None:
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(), method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "pricewatch/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        resp.read()


class ConsoleNotifier:
    name = "console"

    def send(self, subject: str, body: str) -> None:
        print(f"\U0001F6A8 {subject}\n   {body}", flush=True)


class WebhookNotifier:
    name = "webhook"

    def __init__(self, url: str) -> None:
        self.url = url

    def send(self, subject: str, body: str) -> None:
        text = f"{subject}\n{body}"
        _post_json(self.url, {"text": text, "content": text})  # Slack + Discord compatible


class TelegramNotifier:
    name = "telegram"

    def __init__(self, token: str, chat_id: str) -> None:
        self.url = f"https://api.telegram.org/bot{token}/sendMessage"
        self.chat_id = chat_id

    def send(self, subject: str, body: str) -> None:
        _post_json(self.url, {"chat_id": self.chat_id, "text": f"{subject}\n{body}"})


class SmtpNotifier:
    name = "smtp"

    def __init__(self, host: str, port: int, sender: str, to: list[str],
                 username: str | None, password: str | None, starttls: bool = True) -> None:
        self.host, self.port, self.sender, self.to = host, port, sender, to
        self.username, self.password, self.starttls = username, password, starttls

    def send(self, subject: str, body: str) -> None:
        msg = EmailMessage()
        msg["Subject"], msg["From"], msg["To"] = subject, self.sender, ", ".join(self.to)
        msg.set_content(body)
        with smtplib.SMTP(self.host, self.port, timeout=15) as smtp:
            if self.starttls:
                smtp.starttls()
            if self.username and self.password:
                smtp.login(self.username, self.password)
            smtp.send_message(msg)


def build_notifiers(configs: tuple[NotifierConfig, ...]) -> list[Notifier]:
    out: list[Notifier] = []
    for cfg in configs:
        o = cfg.options
        if cfg.type == "console":
            out.append(ConsoleNotifier())
        elif cfg.type == "webhook":
            out.append(WebhookNotifier(_secret(o, "url")))
        elif cfg.type == "telegram":
            out.append(TelegramNotifier(_secret(o, "token"), str(o["chat_id"])))
        elif cfg.type == "smtp":
            to = o.get("to", [])
            out.append(SmtpNotifier(
                host=o["host"], port=int(o.get("port", 587)), sender=o["from"],
                to=[to] if isinstance(to, str) else list(to),
                username=_secret(o, "username", required=False),
                password=_secret(o, "password", required=False),
                starttls=bool(o.get("starttls", True))))
    return out
