"""Command line interface (argparse)."""

from __future__ import annotations

import argparse
import logging
import sys
import time
from importlib import resources
from pathlib import Path

from pricewatch import __version__
from pricewatch.api import CoinGeckoClient, PriceAPIError
from pricewatch.config import ConfigError, Settings, load_config
from pricewatch.engine import Pipeline
from pricewatch.notifiers import ConsoleNotifier, build_notifiers
from pricewatch.scheduler import Scheduler
from pricewatch.storage import Store

DEFAULT_CONFIG = "pricewatch.toml"


def _client(s: Settings) -> CoinGeckoClient:
    return CoinGeckoClient(s.vs_currency, timeout=s.request_timeout, max_retries=s.max_retries)


def _fmt_ts(ts: float) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


# ---- commands ---------------------------------------------------------------
def cmd_init(args: argparse.Namespace) -> int:
    target = Path(args.path)
    if target.exists() and not args.force:
        print(f"error: {target} already exists (use --force to overwrite)", file=sys.stderr)
        return 1
    template = resources.files("pricewatch").joinpath("config.example.toml").read_text("utf-8")
    target.write_text(template, encoding="utf-8")
    print(f"wrote {target}. Edit it, then run: pricewatch validate && pricewatch run --once")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    s = load_config(args.config)
    build_notifiers(s.notifiers)  # also checks that referenced secrets exist
    print(f"OK: {len(s.alerts)} alert(s), {len(s.notifiers)} notifier(s), "
          f"coins={s.coins}, interval={s.interval_seconds}s")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    s = load_config(args.config)
    notifiers = [ConsoleNotifier()] if args.dry_run else build_notifiers(s.notifiers)
    with Store(s.db_path) as store:
        pipeline = Pipeline(s, _client(s), store, notifiers)
        if args.once:
            result = pipeline.run_cycle()
            print(f"fetched {len(result.prices)} price(s); "
                  f"{len(result.triggered)} alert(s) fired, {len(result.suppressed)} suppressed")
            return 0
        scheduler = Scheduler(s.interval_seconds, pipeline.tick)
        scheduler.install_signal_handlers()
        logging.getLogger("pricewatch").info(
            "monitoring %s every %ds (Ctrl+C to stop)", ", ".join(s.coins), s.interval_seconds)
        scheduler.run()
    return 0


def cmd_price(args: argparse.Namespace) -> int:
    client = CoinGeckoClient(args.vs)
    prices = client.get_prices([c.lower() for c in args.coins])
    for coin, price in prices.items():
        print(f"{coin:<16} {price:>16,.2f} {args.vs.upper()}")
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    s = load_config(args.config)
    since = time.time() - args.hours * 3600
    with Store(s.db_path) as store:
        rows = store.history(args.coin.lower(), s.vs_currency, since=since)
    if not rows:
        print("no samples in that window (has `pricewatch run` collected data yet?)")
        return 0
    prices = [r.price for r in rows]
    print(f"{args.coin}: {len(rows)} samples over {args.hours}h")
    print(f"  first {prices[0]:,.2f} | last {prices[-1]:,.2f} | min {min(prices):,.2f} | "
          f"max {max(prices):,.2f} | avg {sum(prices) / len(prices):,.2f} | "
          f"change {(prices[-1] - prices[0]) / prices[0] * 100:+.2f}%")
    for r in rows[-args.tail:]:
        print(f"  {_fmt_ts(r.ts)}  {r.price:>14,.2f}")
    return 0


def cmd_alerts(args: argparse.Namespace) -> int:
    s = load_config(args.config)
    with Store(s.db_path) as store:
        rows = store.recent_alerts(args.limit)
    if not rows:
        print("no alerts have fired yet")
    for r in rows:
        print(f"{_fmt_ts(r['ts'])}  [{r['name']}]  {r['message']}")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    s = load_config(args.config)
    with Store(s.db_path) as store:
        if args.output == "-":
            store.export_csv(sys.stdout, args.coin)
            return 0
        with open(args.output, "w", newline="", encoding="utf-8") as fp:
            n = store.export_csv(fp, args.coin)
    print(f"exported {n} rows to {args.output}")
    return 0


# ---- parser -------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pricewatch", description="Automated crypto price alert bot.")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    p.add_argument("-v", "--verbose", action="count", default=0,
                   help="-v for INFO, -vv for DEBUG logging")
    sub = p.add_subparsers(dest="command", required=True, metavar="<command>")

    def with_config(sp: argparse.ArgumentParser) -> argparse.ArgumentParser:
        sp.add_argument("-c", "--config", default=DEFAULT_CONFIG,
                        help=f"config file (default: {DEFAULT_CONFIG})")
        return sp

    sp = sub.add_parser("init", help="write an example config file")
    sp.add_argument("path", nargs="?", default=DEFAULT_CONFIG)
    sp.add_argument("--force", action="store_true", help="overwrite if it exists")
    sp.set_defaults(func=cmd_init)

    sp = with_config(sub.add_parser("validate", help="check config and notifier secrets"))
    sp.set_defaults(func=cmd_validate)

    sp = with_config(sub.add_parser("run", help="start monitoring (scheduled loop)"))
    sp.add_argument("--once", action="store_true", help="run a single cycle and exit")
    sp.add_argument("--dry-run", action="store_true", help="print alerts to console only")
    sp.set_defaults(func=cmd_run)

    sp = sub.add_parser("price", help="fetch current prices (no config needed)")
    sp.add_argument("coins", nargs="+", help="CoinGecko ids, e.g. bitcoin ethereum")
    sp.add_argument("--vs", default="usd", help="quote currency (default: usd)")
    sp.set_defaults(func=cmd_price)

    sp = with_config(sub.add_parser("history", help="summarise stored price history"))
    sp.add_argument("coin")
    sp.add_argument("--hours", type=float, default=24)
    sp.add_argument("--tail", type=int, default=10, help="rows to print (default: 10)")
    sp.set_defaults(func=cmd_history)

    sp = with_config(sub.add_parser("alerts", help="show recent alert history"))
    sp.add_argument("--limit", type=int, default=20)
    sp.set_defaults(func=cmd_alerts)

    sp = with_config(sub.add_parser("export", help="export price history to CSV"))
    sp.add_argument("-o", "--output", default="prices.csv", help="file path or - for stdout")
    sp.add_argument("--coin", help="only this coin")
    sp.set_defaults(func=cmd_export)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    level = {0: logging.WARNING, 1: logging.INFO}.get(args.verbose, logging.DEBUG)
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    try:
        return args.func(args)
    except (ConfigError, PriceAPIError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
