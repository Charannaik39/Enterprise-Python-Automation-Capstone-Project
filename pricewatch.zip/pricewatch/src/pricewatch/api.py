"""Backend API client: CoinGecko public price endpoint with retry/backoff."""

from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable

log = logging.getLogger(__name__)

Fetcher = Callable[[str, dict[str, str], float], bytes]


class PriceAPIError(RuntimeError):
    """Raised when prices cannot be retrieved after all retries."""


def _urllib_fetch(url: str, headers: dict[str, str], timeout: float) -> bytes:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (https only)
        return resp.read()


class CoinGeckoClient:
    BASE_URL = "https://api.coingecko.com/api/v3"

    def __init__(
        self,
        vs_currency: str = "usd",
        timeout: float = 10.0,
        max_retries: int = 3,
        backoff: float = 1.0,
        base_url: str | None = None,
        fetch: Fetcher | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.vs = vs_currency
        self.timeout = timeout
        self.max_retries = max(1, max_retries)
        self.backoff = backoff
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self._fetch = fetch or _urllib_fetch
        self._sleep = sleep

    def _get_json(self, url: str) -> dict:
        headers = {"Accept": "application/json", "User-Agent": "pricewatch/1.0"}
        last_exc: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            delay = self.backoff * 2 ** (attempt - 1)
            try:
                return json.loads(self._fetch(url, headers, self.timeout))
            except urllib.error.HTTPError as exc:
                if exc.code != 429 and exc.code < 500:
                    raise PriceAPIError(f"HTTP {exc.code} from price API") from exc
                retry_after = exc.headers.get("Retry-After") if exc.headers else None
                if retry_after and retry_after.isdigit():
                    delay = max(delay, float(retry_after))
                last_exc = exc
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
                last_exc = exc
            if attempt < self.max_retries:
                log.warning("API attempt %d/%d failed (%s); retrying in %.1fs",
                            attempt, self.max_retries, last_exc, delay)
                self._sleep(delay)
        raise PriceAPIError(f"price API failed after {self.max_retries} attempts: {last_exc}")

    def get_prices(self, coins: list[str]) -> dict[str, float]:
        """Return {coin_id: price}. Unknown coins are skipped with a warning."""
        if not coins:
            return {}
        query = urllib.parse.urlencode({"ids": ",".join(coins), "vs_currencies": self.vs})
        data = self._get_json(f"{self.base_url}/simple/price?{query}")
        prices: dict[str, float] = {}
        for coin in coins:
            value = data.get(coin, {}).get(self.vs)
            if isinstance(value, (int, float)):
                prices[coin] = float(value)
            else:
                log.warning("No %s price returned for '%s' (check the coin id)", self.vs, coin)
        if not prices:
            raise PriceAPIError("API returned no usable prices")
        return prices
